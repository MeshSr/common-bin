#/bin/sh

# the purpose of this script is to flash u-boot, Linux, 
# and the Linux ramdisk to QSPI flash

path=$1

if [ $# -ne 1 ] ; then
	echo "usage: update_qspi.sh <path to images>"
	exit
fi

printf "\nWriting U-boot Image To QSPI Flash\n\n"

flashcp -v $path/qspi-u-boot.bin /dev/mtd13

printf "\nWriting Linux Image To QSPI Flash\n\n"

flashcp -v $path/vmlinux.bin /dev/mtd15

printf "\nWriting Ramdisk Image To QSPI Flash\n\n"

flashcp -v $path/ramdisk8M.image.gz /dev/mtd18
